/**
 * @file CommunicationControler.cpp
 *
 * @author Nathan Schaaphuizen
 * @date 24 okt. 2016
 */
#include "CommunicationControler.h"
#include "TaskBase.h"
#include "AtClient.h"
#include "HttpClient.h"
#include "Queue.h"
#include "ArrayList.h"
#include "Aes.h"
#include "Base64.h"
#include <math.h>
#include "Debug.h"

CommunicationControler* CommunicationControler::instance = nullptr;
long long CommunicationControler::globalMessageCounter = 0;

CommunicationControler & CommunicationControler::getInstance(){
	if(instance == nullptr){
		instance = new CommunicationControler();
	}
	return *instance;
}

CommunicationControler::CommunicationControler():
TaskBase(2, "CommunicationTask"),
http(AtClient::getInstance()),
gsm(GsmClient::getInstance()),
sendQueue(20),
smsQueue(10),
aes(nullptr),
ip("0.0.0.0"),
phoneNumber("0000000000"),
ccid("000000000000000000"),
ready(true)
{
	pinMode(6, OUTPUT);
}


void CommunicationControler::encrypt(String &message){
	//Add space padding to make the string length a multiple of 16.
	//This is required for AES.
	while(message.length() % 16 != 0){
		message += " ";
	}
	//Encrypt using AES.
	unsigned char *buffer = new unsigned char[message.length()];
	aes->encrypt((unsigned char*)message.c_str(), buffer, message.length());
	//Encode using Base64.
	message = base64_encode(buffer, message.length());
	delete buffer;
}

void CommunicationControler::decrypt(String &message){
	//Decode using Base64
	String ciphertext = base64_decode(message);
	//Decrypt using AES.
	unsigned char *decryptBuffer = new unsigned char[ciphertext.length() + 1];
	aes->decrypt((unsigned char*)ciphertext.c_str(), decryptBuffer, ciphertext.length());
	decryptBuffer[ciphertext.length()] = '\0';
	String plainResponse((const char*)decryptBuffer);
	delete decryptBuffer;
	message = plainResponse.trim();
}

void CommunicationControler::sendSms(){
	SmsPackage p = smsQueue.pop();
	String number = *p.number;
	delete p.number;
	String text = *p.text;
	delete p.text;
	if(gsm.isDeviceOpen()){
		if(!gsm.sendSms(number, text)){
			PRINTLN("Error Sensing SMS.");
		}
	}
	else{
		PRINTLN("Error AT device not connected.");
	}
}

void CommunicationControler::sendInternet(){
	Package p = sendQueue.pop();
	String message = *p.message;
	delete p.message;
	String url = *p.url;
	delete p.url;
	if(http.isDeviceOpen()){
		if(!http.isConnected()){
			for(int i=0; i<3 && !http.connect(); i++){
				sleep(3000);
			}
		}

		if(http.isConnected()){
			//Encrypt if necessary.
			if(aes != nullptr){
				encrypt(message);
			}
			//Post or get data.
			String rsp;
			if(p.post){
				rsp = http.post(url, message, HttpClient::CONTENT_TYPE_JSON);
			}
			else{
				rsp = http.get(url);
			}
			int status = http.getStatus();
			//Decrypt if necessary.
			if(aes != nullptr && rsp.length() > 0){
				decrypt(rsp);
			}

			if(p.callbackObj != nullptr){
				p.callbackObj->onMessageReceived(p.messageId, status, rsp);
			}
		}
		else{
			PRINTLN("Error no Internet connection.")
			if(p.callbackObj != nullptr){
					p.callbackObj->onMessageReceived(p.messageId, -1, String());
			}
		}
	}
	else{
		PRINTLN("Error AT device not connected.");
		if(p.callbackObj != nullptr){
			p.callbackObj->onMessageReceived(p.messageId, -1, String());
		}
	}
}

void CommunicationControler::run(){
	PRINTLN("-----------------Communication Task Start-----------");
	//Power on device
	if(!http.isDeviceOpen()){
		//Make the PWR pin high for 1 second.
		//This will boot the GRPS it was off.
		digitalWrite(6, HIGH);
		sleep(1000);
		digitalWrite(6, LOW);
		//Wait 5 sec for device to start up.
		sleep(5000);
	}


	if(http.isDeviceOpen() || http.openDevice()){
		//Open connection with device.
		while(!http.openDevice()){
			PRINTLN("Failed to open communication to AT device.")
			sleep(100);
		}

		//Set the pin code if needed.
		if(gsm.getPinState() == GsmClient::SIM_PIN){
			PRINTLN("PIN required, setting pin code '0000'.")
			if(!gsm.setPinCode("0000")){
				PRINTLN("Failed to set PIN.");
			}
		}

		//Get the phone number.
		while(!gsm.getPhoneNumber(phoneNumber)){
			PRINTLN("Failed to fetch phone number.")
			sleep(100);
		}

		//Get the ccid.
		while(!gsm.getCcid(ccid)){
			PRINTLN("Failed to fetch the CCID.")
			sleep(100);
		}

		//Weak signal warning.
		if(gsm.getSignalQuality() < 10){
			PRINTLN("Warning: weak signal.");
		}

		//Try to connect to Internet a few times.
		for(int i=0; i<3 && !http.connect(); i++){
			sleep(1000);
		}

		//Get the IP address.
		if(http.isConnected()){
			ip = http.getIp();
		}
	}
	else{
		PRINTLN("No AT device found, Communication Task suspend.");
		ready = false;
		//suspend();
	}

	while(true){
		const Waitable *w = wait(smsQueue | sendQueue);
		if(w == &smsQueue){
			sendSms();
		}
		else{
			sendInternet();
		}
	}
}

void CommunicationControler::enableEncryption(const String& key){
	if(aes != nullptr){
		delete aes;
	}
	aes = new Aes(key);
}

void CommunicationControler:: disableEncryption(){
	delete aes;
}

long long CommunicationControler::sendPostRequest(const String &url, const String& data, CommunicationListener *callback){
	Package p;
	p.callbackObj = callback;
	p.message = new String(data);
	p.url = new String(url);
	p.messageId = globalMessageCounter++;
	p.post = true;
	//Do not push to queue if task is suspended to prevent the queue form filling and blocking the whole system.
	sendQueue.push(p);
	return p.messageId;
}

long long CommunicationControler::sendGetRequest(const String &url, CommunicationListener *callback){
	Package p;
	p.callbackObj = callback;
	p.message = new String();
	p.url = new String(url);
	p.messageId = globalMessageCounter++;
	p.post = false;
	//Do not push to queue if task is suspended to prevent the queue form filling and blocking the whole system.
	sendQueue.push(p);
	return p.messageId;
}

void CommunicationControler::sendSms(const String &number, const String &text){
	SmsPackage p;
	p.number = new String(number);
	p.text = new String(text);
	//Do not push to queue if task is suspended to prevent the queue form filling and blocking the whole system.
	smsQueue.push(p);
}

String CommunicationControler::getIpAddress(){
	return ip;
}

String CommunicationControler::getPhoneNumber(){
	return phoneNumber;
}

String CommunicationControler::getCcid(){
	return ccid;
}
